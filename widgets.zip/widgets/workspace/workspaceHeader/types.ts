export enum TileView {
  Normal = 'Normal',
  Analytics = 'Analytics',
}
