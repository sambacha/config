export { default } from './FooterVersion'
