import React, { useCallback } from 'react'
import { ContactUsContent, Link, Input } from './styled'
import { handleBrowserLink } from './utils'
import { EventArgs } from 'react-ga'

const WEBSITE = 'https://freighttrust.com'

const ContactUs: React.FC = () => {
  const onClick = useCallback(
    (args: EventArgs, href: string) => () => {
      handleBrowserLink(args, href)
    },
    []
  )
  return (
    <ContactUsContent>
      <span className="header">Contact us</span>
      <div>
        <span>support@freight.zendesk.com</span>
        <span></span>
      </div>
      <div>
        <span>https://github.com/freight-trust</span>
        <span>https://t.me/freighttrust</span>
      </div>

      <Input value="https://freight.page.link/demo" readOnly />

      <Link
        onClick={onClick(
          {
            category: 'RT - Outbound',
            action: 'click',
            label: WEBSITE,
            transport: 'beacon'
          },
          WEBSITE
        )}
      >
        www.freighttrust.com
      </Link>
    </ContactUsContent>
  )
}

export default ContactUs

/*
  ca
*/
