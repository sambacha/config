export interface HistoricPosition {
  timestamp: Date
  usdPnl: number
}
