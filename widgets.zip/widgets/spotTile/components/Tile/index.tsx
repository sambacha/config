export { default } from './Tile'
