export type ValidationMessage = {
  type: 'warning' | 'error' | 'info'
  content: string
}
