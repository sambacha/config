export enum PriceMovementTypes {
  Up = 'Up',
  Down = 'Down',
  None = 'None'
}
