export interface Rate {
  bigFigure: number
  rawRate: number
  ratePrecision: number
  pipFraction: number
  pipPrecision: number
  pips: number
}
